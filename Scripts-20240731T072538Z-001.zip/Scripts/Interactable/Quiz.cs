using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class Quiz : MonoBehaviour
{
    public GameObject texte;
    public FileManager fileMan;
    public Sprite[] spriteList;
    public Sprite[] noteList;
    public Sprite[] noteListE;
    public string[] stringList;
    public int[] answerList;
    public GameObject noteScreen;
    public int n;
    public int j;
    public int count;
    public int greseliTotale;
    public static int greselSalvare;
    public static int scorSalvare;
    public Door dor;
    public bool cooldown;
    public TextMeshProUGUI Scor;
    public TextMeshProUGUI incurajare;
    public TextMeshProUGUI RaspGres;
    public TextMeshProUGUI RaspGresScor;
    public TextMeshProUGUI ScorPeBune;
    public GameObject textScor;
    public bool finish;
    public int chapter;
    public GameObject hint;
    public bool engleza;
    public Sprite hintEnglish;
    

    void Start()
    {
        if(fileMan.limba != "Romana")
        engleza = true;
        j = 0;
        cooldown = true;
        Shuffle();
        fileMan.ReadFromFile(stringList[0]);
        if(!engleza)
        {
            noteScreen.gameObject.GetComponent<Image>().sprite = noteList[0];
            
        }
        else 
        {
            noteScreen.gameObject.GetComponent<Image>().sprite = noteListE[0];
            hint.gameObject.GetComponent<Image>().sprite = hintEnglish;
        }

    }

   

    public void Shuffle()
    {
        int l = stringList.Length;
        while(l > 1)
        {
           
            l--;
            int k = Random.Range(0, l + 1);
            string s = stringList[k];
            int m = answerList[k];
            Sprite q = noteList[k];
            Sprite w = noteListE[k];
            stringList[k] = stringList[l];
            answerList[k] = answerList[l];
            noteList[k] = noteList[l];
            noteListE[k] = noteList[l];
            answerList[l] = m;
            stringList[l] = s;
            noteList[l] = q;
            noteListE[l] = q;
        }
    }

    public void Hint()
    {
        hint.SetActive(false);
    }
    

    public void Answer(int ras)
    {
        if(cooldown && !finish)
        {
            j++;
            if(j == stringList.Length)
                {
                    texte.SetActive(false);
                    this.gameObject.GetComponent<Image>().sprite = spriteList[0];
                    noteScreen.gameObject.GetComponent<Image>().sprite = noteList[0];
                    StartCoroutine(SchimbaFin());
                    FindObjectOfType<AudioManager>().Play("Correct");
                }
            else if(ras == answerList[n] && cooldown)
            {
                cooldown = false;
                StartCoroutine(Cooldown());
                
                texte.SetActive(false);
                this.gameObject.GetComponent<Image>().sprite = spriteList[0];
                    StartCoroutine(Schimba());
                    FindObjectOfType<AudioManager>().Play("Correct");

                    Debug.Log("right");
                

            }
                
                //
            else 
            {
                if(cooldown)
                {
                    j++;
                    cooldown = false;
                    StartCoroutine(Cooldown());
                    if(j == stringList.Length)
                    {
                        
                        texte.SetActive(false);
                        this.gameObject.GetComponent<Image>().sprite = spriteList[1];
                        StartCoroutine(SchimbaFin());
                        FindObjectOfType<AudioManager>().Play("Wrong");
                    }
                    else
                    {
                        count++;
                        greseliTotale++;
                        j--;
                        if(count != 3)
                        {
                            texte.SetActive(false);
                            this.gameObject.GetComponent<Image>().sprite = spriteList[1];
                            StartCoroutine(Schimba());
                            FindObjectOfType<AudioManager>().Play("Wrong");
                        }

                        else
                        {
                            texte.SetActive(false);
                            this.gameObject.GetComponent<Image>().sprite = spriteList[2];
                            StartCoroutine(SchimbaGr());
                            FindObjectOfType<AudioManager>().Play("Wrong");
                        }
                    }
                }
                
            }
        }
          
            
            //

    }
    IEnumerator Cooldown()
    {
        n++;
        yield return new WaitForSeconds(3f);
        cooldown = true;
    }

    IEnumerator Schimba()
    {   
        yield return new WaitForSeconds(3f);
        ChangeImage(j);   
    }

    IEnumerator SchimbaGr()
    {
        hint.SetActive(false);
        yield return new WaitForSeconds(3f);
        Greseli();
    }

    IEnumerator SchimbaFin()
    {
        
        if(chapter == 1)
        {
           ButoaneLift.complet1 = true;
        }
        if(chapter == 2)
        {
           ButoaneLift.complet2 = true;
        }
        if(chapter == 3)
        {
           ButoaneLift.complet3 = true;
        }
        if(chapter == 4)
        {
           ButoaneLift.complet4 = true;
        }
        
        dor.IsLocked = false;
        yield return new WaitForSeconds(3f);
        this.gameObject.GetComponent<Image>().sprite = spriteList[3];
        texte.SetActive(false);
        textScor.SetActive(true);
        Scor.text = 10 - count + " / 10";
        ScorPeBune.text = 10 - count + " / 10";
        scorSalvare += count;
        greselSalvare += greseliTotale;
        RaspGres.text = greseliTotale + " raspunsuri gresite in total";
        RaspGresScor.text = greseliTotale + " raspunsuri gresite in total";
        if(greseliTotale < 1)
        {
            incurajare.text = "Absolut perfect!";
            incurajare.color = new Color(255, 215, 0, 1);
        }
        
        
        else if( greseliTotale >= 1 && greseliTotale < 3)
        {
            incurajare.text = "Aproape perfect";
            incurajare.color = Color.yellow;
        }
        
        else if(greseliTotale >= 3 && greseliTotale < 7)
        {
            incurajare.text = "Destul de bine";
            incurajare.color = Color.green;
        }
        
        else if(greseliTotale >=7 && greseliTotale < 9)
        {
            incurajare.text = "Binisor...Sa zicem";
            incurajare.color = incurajare.color = new Color(255, 255, 0, 1);
        }
        
        else if(greseliTotale > 9)
        {
            incurajare.text = "Ar fi trebuit sa te uiti mai bine pe tutorial...";
            incurajare.color = Color.red;
        }
        
    
        
    }
    public void ChangeImage(int i)
    {
        hint.SetActive(true);
        texte.SetActive(true);
        this.gameObject.GetComponent<Image>().sprite = spriteList[4];
        fileMan.ReadFromFile(stringList[i]);
        if(!engleza)
        noteScreen.gameObject.GetComponent<Image>().sprite = noteList[i];
        else noteScreen.gameObject.GetComponent<Image>().sprite = noteListE[i];
    }
    
    public void Greseli()
    {
        Shuffle();
        count = 0;
        n = 0;
        j = 0;
        ChangeImage(j);
        
    }
}
