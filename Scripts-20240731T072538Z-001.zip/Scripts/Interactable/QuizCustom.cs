using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.IO;

public class QuizCustom : MonoBehaviour
{
    public GameObject texte;
    public FileManager fileMan;
    public Sprite[] spriteList;
    public List <string> stringList;
    public GameObject noteScreen;
    public int n;
    public int j;
    public int count;
    public int greseliTotale;
    public static int greselSalvare;
    public static int scorSalvare;
    public bool cooldown;
    public TextMeshProUGUI Scor;
    public TextMeshProUGUI incurajare;
    public TextMeshProUGUI RaspGres;
    public TextMeshProUGUI RaspGresScor;
    public TextMeshProUGUI ScorPeBune;
    public GameObject textScor;
    public bool finish;
    public GameObject hint;
    string myFilePath;
    public string folderName;
    public TextMeshProUGUI raspCor;
    public int rasp;
    public Explorer ex;
    public bool started;


        

    public void StartQuiz()
    {
        stringList = ex.dir;
        j = 0;
        cooldown = true;
        fileMan.ReadFromCustomFile(stringList[0]);
        started = true;
    }

   

    

    public void Hint()
    {
        hint.SetActive(false);
    }
    

    public void Answer(int ras)
    {

       if(raspCor.text.Contains("A"))
        rasp = 1;
        else if(raspCor.text.Contains("B"))
        rasp = 2;
        else if(raspCor.text.Contains("C"))
        rasp = 3;
        else if(raspCor.text.Contains("D"))
        rasp = 4;
        if(cooldown && !finish)
        {
            j++;
            if(j == stringList.Count)
                {
                    texte.SetActive(false);
                    this.gameObject.GetComponent<Image>().sprite = spriteList[0];
                    StartCoroutine(SchimbaFin());
                    FindObjectOfType<AudioManager>().Play("Correct");
                }
            else if(ras == rasp && cooldown)
            {
                cooldown = false;
                StartCoroutine(Cooldown());
                
                texte.SetActive(false);
                this.gameObject.GetComponent<Image>().sprite = spriteList[0];
                StartCoroutine(Schimba());
                FindObjectOfType<AudioManager>().Play("Correct");
                

            }
                
                //
            else 
            {
                if(cooldown)
                {
                    j++;
                    cooldown = false;
                    StartCoroutine(Cooldown());
                    if(j == stringList.Count)
                    {
                        
                        texte.SetActive(false);
                        this.gameObject.GetComponent<Image>().sprite = spriteList[1];
                        StartCoroutine(SchimbaFin());
                        FindObjectOfType<AudioManager>().Play("Wrong");
                    }
                    else
                    {
                        count++;
                        greseliTotale++;
                        j--;
                        if(count != 3)
                        {
                            texte.SetActive(false);
                            this.gameObject.GetComponent<Image>().sprite = spriteList[1];
                            StartCoroutine(Schimba());
                            FindObjectOfType<AudioManager>().Play("Wrong");
                        }

                        else
                        {
                            texte.SetActive(false);
                            this.gameObject.GetComponent<Image>().sprite = spriteList[2];
                            StartCoroutine(SchimbaGr());
                            FindObjectOfType<AudioManager>().Play("Wrong");
                        }
                    }
                }
                
            }
        }
          
            
            //

    }
    IEnumerator Cooldown()
    {
        n++;
        yield return new WaitForSeconds(3f);
        cooldown = true;
    }

    IEnumerator Schimba()
    {   
        yield return new WaitForSeconds(3f);
        ChangeImage(j);   
    }

    IEnumerator SchimbaGr()
    {
        hint.SetActive(false);
        yield return new WaitForSeconds(3f);
        Greseli();
    }

    IEnumerator SchimbaFin()
    { 
        yield return new WaitForSeconds(3f);
        this.gameObject.GetComponent<Image>().sprite = spriteList[3];
        texte.SetActive(false);
        textScor.SetActive(true);
        Scor.text = 10 - count + " / 10";
        ScorPeBune.text = 10 - count + " / 10";
        scorSalvare += count;
        greselSalvare += greseliTotale;
        RaspGres.text = greseliTotale + " raspunsuri gresite in total";
        RaspGresScor.text = greseliTotale + " raspunsuri gresite in total";
        if(greseliTotale < 1)
        {
            incurajare.text = "Absolut perfect!";
            incurajare.color = new Color(255, 215, 0, 1);
        }
        
        
        else if( greseliTotale >= 1 && greseliTotale < 3)
        {
            incurajare.text = "Aproape perfect";
            incurajare.color = Color.yellow;
        }
        
        else if(greseliTotale >= 3 && greseliTotale < 7)
        {
            incurajare.text = "Destul de bine";
            incurajare.color = Color.green;
        }
        
        else if(greseliTotale >=7 && greseliTotale < 9)
        {
            incurajare.text = "Binisor...Sa zicem";
            incurajare.color = incurajare.color = new Color(255, 255, 0, 1);
        }
        
        else if(greseliTotale > 9)
        {
            incurajare.text = "Ar fi trebuit sa te uiti mai bine pe tutorial...";
            incurajare.color = Color.red;
        }
        
    
        
    }
    public void ChangeImage(int i)
    {
        hint.SetActive(true);
        texte.SetActive(true);
        this.gameObject.GetComponent<Image>().sprite = spriteList[4];
        fileMan.ReadFromCustomFile(stringList[i]);
    }
    
    public void Greseli()
    {
        count = 0;
        n = 0;
        j = 0;
        ChangeImage(j);
        
    }
}
