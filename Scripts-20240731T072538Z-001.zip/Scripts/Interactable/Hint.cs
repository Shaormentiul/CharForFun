using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Hint : Interactable
{
    public GameObject hintBlock;

    protected override void Interact()
    {
        hintBlock.SetActive(false);
    }
   
}
