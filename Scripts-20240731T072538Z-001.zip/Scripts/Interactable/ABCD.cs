using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ABCD : Interactable
{
    public int i;
    public Quiz q;
    public QuizCustom qs;
    public bool isCustom;
    public GameObject Screen;

    protected override void Interact()
    {
        if(!isCustom)
        q.Answer(i);
        else {
            qs.Answer(i);
            if(!qs.started)
            {
                qs.StartQuiz();
                Screen.SetActive(false);
            }
            
        }
    }
}
