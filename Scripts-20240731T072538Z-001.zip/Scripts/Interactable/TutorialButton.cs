using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ButonTutorial : Interactable
{
    public bool right;
    public Tutorial tut;

    protected override void Interact()
    {
        if(right)
        {
            tut.Right();
        }
        else tut.Left();
    }
}
