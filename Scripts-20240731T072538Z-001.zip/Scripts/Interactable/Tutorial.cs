using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Tutorial : MonoBehaviour
{
    int i;
    public Sprite[] spriteList;

    public void Right()
    {
        if(i != spriteList.Length - 1)
        {
            this.gameObject.GetComponent<Image>().sprite = spriteList[i + 1];
            i++;
        }
        
        Debug.Log(i);
    }

    public void Left()
    {
        if(i != 0)
        {
            this.gameObject.GetComponent<Image>().sprite = spriteList[i - 1];
            i--;
        }
        
        Debug.Log(i);
    }
}
