using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EditButton : Interactable
{

    public PlayerMotor motor;
    public PlayerLook look;
    public GameObject player;
    public GameObject camera;
    float duration = 2f;
    float elapsedTime = 0f;
    public GameObject buton;
    public QuizCustom qs;

    protected override void Interact()
    {
        buton.SetActive(true);
        motor.allowed = false;
        look.allowed = false;
        motor.Cursors();
        player.transform.rotation = new Quaternion(0f, 90f, 0f, 90f);
        camera.transform.rotation = new Quaternion(0f, 0f, 0f, 0f);
        player.transform.position = new Vector3(-49.54f, 1.414f, 101.247f); 
        qs.StartQuiz();
    }

    public void NoMore()
    {
        motor.allowed = true;
        look.allowed = true;
        motor.CursorsNo();
    }
}
