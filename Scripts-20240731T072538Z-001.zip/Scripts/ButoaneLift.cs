using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ButoaneLift : MonoBehaviour
{
    public static bool complet1;
    public static bool complet2;
    public static bool complet3;
    public static bool complet4;
    public GameObject buton2;
    public GameObject buton3;
    public GameObject buton4;
    public GameObject buton5;

    void Update()
    {
        if(complet1)
        buton2.SetActive(true);
        if(complet2)
        buton3.SetActive(true);
        if(complet3)
        buton4.SetActive(true);
        if(complet4)
        buton5.SetActive(true);
    }
    
}
