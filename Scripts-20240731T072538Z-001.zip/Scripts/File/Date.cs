using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Date : MonoBehaviour
{
    public int greselSalv;
    public bool progres1;
    public bool progres2;
    public bool progres3;
    public bool progres4;
    public int note;
    public int testy;


    void Update()
    {
        greselSalv = Quiz.greselSalvare;
        progres1 = ButoaneLift.complet1;
        progres2 = ButoaneLift.complet2;
        progres3 = ButoaneLift.complet3;
        progres4 = ButoaneLift.complet4;
        note = Quiz.scorSalvare;
        SavePlayer();

    }


    void Start()
    {
        LoadPlayer();
    }

    

     public void SavePlayer()
    {
        SaveSystem.SavePlayer(this);
    }

    public void LoadPlayer()
    {
        PlayerData data = SaveSystem.LoadPlayer();
        ButoaneLift.complet1 = data.progress1;
        ButoaneLift.complet2 = data.progress2;
        ButoaneLift.complet3 = data.progress3;
        ButoaneLift.complet4 = data.progress4;
        Quiz.greselSalvare = data.greseliLaFinal;
        Quiz.scorSalvare = data.nota;
    }

}
