using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using TMPro;

public class FileManager : MonoBehaviour
{
    public TextMeshProUGUI codeBox;
    public TextMeshProUGUI promptBox;
    public TextMeshProUGUI ABox;
    public TextMeshProUGUI BBox;
    public TextMeshProUGUI CBox;
    public TextMeshProUGUI DBox;
    public TextMeshProUGUI title;
    public TextMeshProUGUI raspValue;

    public string limba;
    public string numeCapitol;
    string [] namesArray;
    public string [] fileArray;
    int i;
    string myFilePath;

    

    // Update is called once per frame
    public void ReadFromFile(string fileName)
    {
        myFilePath = Application.dataPath + "/StreamingAssets"+ "/" + "Texte" + "/" + limba + "/" + numeCapitol + "/" + fileName;
        i = 0;
        namesArray = File.ReadAllLines(myFilePath);
        codeBox.text = null; 
        while(namesArray[i] != "[spatiu]")
        {
            codeBox.text += '\n' + namesArray[i];
            i++;
        }
        i++;
        promptBox.text = null;
        while(namesArray[i] != "[spatiu]")
        {
            promptBox.text += '\n' + namesArray[i];
            i++;
        }
        int font = int.Parse(namesArray[i+1]);
        ABox.text = namesArray[i+2];
        BBox.text = namesArray[i+3];
        CBox.text = namesArray[i+4];
        DBox.text = namesArray[i+5];
        ABox.fontSize = font;
        BBox.fontSize = font;
        CBox.fontSize = font;
        DBox.fontSize = font;
           
        
       
        
    }

    public void ReadFromCustomFile(string fileName)
    {
        myFilePath = fileName;
        i = 0;
        namesArray = File.ReadAllLines(myFilePath);
        codeBox.text = null; 
        
        while(namesArray[i] != "[spatiu]")
        {
            codeBox.text += '\n' + namesArray[i];
            i++;
        }
        i++;
        promptBox.text = null;
        while(namesArray[i] != "[spatiu]")
        {
            promptBox.text += '\n' + namesArray[i];
            i++;
        }
        int font = int.Parse(namesArray[i+1]);
        ABox.text = namesArray[i+2];
        BBox.text = namesArray[i+3];
        CBox.text = namesArray[i+4];
        DBox.text = namesArray[i+5];
        raspValue.text = (namesArray[i+6]);
        ABox.fontSize = font;
        BBox.fontSize = font;
        CBox.fontSize = font;
        DBox.fontSize = font;

           
        
       
        
    }
}
