﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using System;
using UnityEngine;
using UnityEngine.UI;
using SmartDLL;
using TMPro;

public class Explorer : MonoBehaviour
{
    public TMP_InputField cod;
    public TMP_InputField intrebare;
    public TMP_InputField RaspA;
    public TMP_InputField RaspB;
    public TMP_InputField RaspC;
    public TMP_InputField RaspD;
    public TMP_InputField Titlu;
    public TMP_InputField rasp;
    public TMP_InputField folderNamer;
    public int font;
    public string textResult;
    public string processedText;
    public string folderName;
    public string problemName;
    public QuizCustom quiz;
    public SmartFileExplorer fileExplorer = new SmartFileExplorer();
    public int i;

    private bool readText = false;

    public List <string> dir;

    public string[] folders;

    string filePath = Application.dataPath + "/StreamingAssets/Custom/titles.txt"; 
    
    

    // Update is called once per frame
    void Update()
    {
        if (fileExplorer.resultOK && readText)
        {
            ReadText(fileExplorer.fileName);
            readText = false;
            folders = File.ReadAllLines(filePath);
        }
        dir = new List<string>(Directory.GetFiles(Application.dataPath + "/StreamingAssets/Custom"));
        for(i = 0 ; i < dir.Count ; i++)
        {
            if(dir[i].Contains("meta"))
            dir.RemoveAt(i);
        }
    }

    public void ShowExplorer()
    {
        string initialDir = @"C:\";
        bool restoreDir = true;
        string title = "Open a Text File";
        string defExt = "";
        string filter = "";

        fileExplorer.OpenExplorer(initialDir,restoreDir,title,defExt,filter);
        readText = true;
    }

    void ReadText(string path)
    {
        processedText = File.ReadAllText(path);
    }

    public void Proccesor()
    {
        textResult = cod.text + "\n[spatiu]" + "\n" + intrebare.text + "\n" + "[spatiu]" + "\n" + font.ToString() + "\n" + RaspA.text + "\n" + RaspB.text + "\n" + RaspC.text + "\n" + RaspD.text + "\n" + rasp.text;
        WriteAll();
    }

    public void NewFile()
    {
        Debug.Log("YA");
        cod.Select();
        cod.text = "";
        intrebare.Select();
        intrebare.text = "";
        RaspA.Select();
        RaspA.text = "";
        RaspB.Select();
        RaspB.text = "";
        RaspC.Select();
        RaspC.text = "";
        RaspD.Select();
        RaspD.text = "";
        Titlu.Select();
        Titlu.text = "";
        rasp.Select();
        rasp.text = "";
        font = 20;
    }


    void WriteAll()
    {
        File.WriteAllText(Application.dataPath + "/StreamingAssets" + "/" + "Custom" + "/" + folderName + "/" + "Probleme/" + Titlu.text + ".txt", textResult);
    }

    public TMP_Dropdown drop;

}