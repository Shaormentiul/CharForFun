using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class PlayerData 
{
   public bool progress1;
   public bool progress2;
   public bool progress3;
   public bool progress4;
   public int greseliLaFinal;
   public int nota;
   public int testt;

   public PlayerData(Date date)
   {
        progress1 = date.progres1;
        progress2 = date.progres2;
        progress3 = date.progres3;
        progress4 = date.progres4;
        nota = date.note;
        greseliLaFinal = date.greselSalv;
        testt = date.testy;
    
   }


   
}
