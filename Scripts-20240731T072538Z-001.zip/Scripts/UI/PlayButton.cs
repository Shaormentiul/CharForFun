using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Video;

public class PlayButton : Interactable
{
    public VideoPlayer video;

    void Start()
    {
        video.Pause();
    }

    protected override void Interact()
    {
        if(!video.isPaused)
        {
            video.Pause();
        }
        else video.Play();
    }

    void Update()
    {
        if(video.time == video.length)
        {
            video.Stop();
        }
    }
}
